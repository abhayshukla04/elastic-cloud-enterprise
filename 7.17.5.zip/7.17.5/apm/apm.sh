#!/bin/bash
# APM Server Mode: {{ apmServerMode|default("standalone") }}

set -e

function prepend-with-date {
  while read line
  do
    echo $(date +%Y-%m-%dT%H:%M:%S%z) $line
  done
}

{% set cluster_data = jsonMap(container.clusterData()) %}
{% set instance_data = jsonMap(container.instanceData()) %}
{% set majorVersion = container.parsedVersion().major() %}
{% set minorVersion = container.parsedVersion().minor() %}
{% set patchVersion = container.parsedVersion().patch() %}

if [[ $(id -u) -eq 0 ]]; then
    echo "ERROR: apm.sh running as uid 0 (root), exiting."
    exit 1
fi

cd /app

mkdir -p logs
BOOT_LOG_FILE=logs/boot.log
# save stdout and stderr for later
exec 3>&1 4>&2
exec >  >(prepend-with-date | tee -a $BOOT_LOG_FILE)
exec 2> >(prepend-with-date | tee -a $BOOT_LOG_FILE >&2)

echo "Booting at $(date)"

# used by metricbeat
export ECE_COMPONENT="apm"
export ECE_CLUSTER_NAME="{{ container.id().group() }}"
export ECE_INSTANCE_ID="{{ container.id().name() }}"
export ECE_CLUSTER_VERSION="{{ container.versionString() }}"

# restore stdout and stderr
exec 1>&3 2>&4

{% if instance_data.apm.debug_enabled|default(false) %}
# we do not use -e option as we want the things to be logged to apm.log and not to standard error (as we do not log that)
  {% set debug_enabled_flag = '-d "*" ' %}
{% else %}
  {% set debug_enabled_flag = "" %}
{% endif %}

HOME_PATH=/app
CONFIG_PATH=/app/config
DATA_PATH=/app/data
LOGS_PATH=/app/logs

{% if majorVersion == 6 or (majorVersion == 7 and minorVersion <= 12) %}
# Logic for legacy APM Server running in container (< 7.13)

{% if majorVersion == 6 and minorVersion <= 6 %}
cp /usr/share/apm-server/fields.yml ${CONFIG_PATH}/
cp -Rf /usr/share/apm-server/kibana ${HOME_PATH}/ || true
{% set basePath = "/usr/share/apm-server" %}
{% else %}
{% set basePath = "/apm-server" %}
{% endif %}

cp -Rf {{ basePath }}/ingest ${HOME_PATH}/ || true
echo "Done preparing, starting Apm. See Apm logs for further output."
{{ basePath }}/apm-server {{ debug_enabled_flag }}-c /app/config/apm-server.yml --httpprof :{{ container.monitoringPort() }} --path.home=${HOME_PATH} --path.config=${CONFIG_PATH} --path.data=${DATA_PATH} --path.logs=${LOGS_PATH} $*

{% else %}

export ELASTIC_AGENT_CLOUD=true
export STATE_PATH="${HOME_PATH}/elastic-agent"
export HOME_PATH=${HOME_PATH}
export LOGS_PATH=${LOGS_PATH}
export CONFIG_PATH=${CONFIG_PATH}
export DATA_PATH=${DATA_PATH}
export HTTPPROF=:{{ container.monitoringPort() }}
# avoid associating freed memory pages with the process
# aligned with go1.16 defaults
export GODEBUG='madvdontneed=1'
# GOGC (percentage) defaults to 100
# GC is triggered when the ratio of newly allocated heap compared to the heap size after the last collection reaches this percentage.
export GOGC=20
export APMSERVER_GOGC=70
# set deployment size
export CLOUD_APM_CAPACITY={{ instance_data.instance_capacity }}
# only export apm-server standalone server path if not already migrated
{% if apmServerMode|default("standalone") == "standalone" %}
export APM_SERVER_PATH="${HOME_PATH}/apm-server/"
{% endif %}

echo "Done preparing, starting Elastic Agent and Apm. See Elastic Agent and Apm logs for further output."
/usr/share/elastic-agent/elastic-agent container {{ debug_enabled_flag }} $*

{% endif %}

EXIT_CODE=$?
exit $EXIT_CODE
