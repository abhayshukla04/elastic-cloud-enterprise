#!/bin/sh

{% if filebeatEnabled is defined && filebeatEnabled %}

echo "Filebeat configured to run, starting monitor"

if [ ! -d /filebeat ]; then
  mkdir /filebeat

  chown {{filebeatRunAsUser}}: /filebeat
fi

{% if filebeatBinPath is defined %}
{{filebeatBinPath}}/setuser {{filebeatRunAsUser}} /app/filebeat.sh &
{% else %}
setuser {{filebeatRunAsUser}} /app/filebeat.sh &
{% endif %}

{% else %}

echo "Filebeat not configured to run, skipping"

{% endif %}
