#!/bin/sh

# Trace commands for better observability
set -x

{% if filebeatEnabled is defined && filebeatEnabled %}

echo "Extracting Filebeat"

tar xfp /app/filebeat.tar.gz -C /filebeat --strip-components=1 --overwrite

echo "Starting Filebeat"

# avoid associating freed memory pages with the process
# aligned with go1.16 defaults
export GODEBUG='madvdontneed=1'

# Run filebeat in a loop. If it exits, it will keep trying to run
while true; do
  if [ -f /opt/filebeat/filebeat ]; then
    /opt/filebeat/filebeat --path.config /app/config/filebeat --path.data /tmp/filebeat-data
  else
    /filebeat/filebeat --path.config /app/config/filebeat
  fi
  echo "Filebeat exited with code $?. Re-running in {{filebeatTimeBetweenRetries}} seconds"
  sleep {{filebeatTimeBetweenRetries}}
done

{% endif %}
