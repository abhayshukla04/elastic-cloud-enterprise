#!/bin/sh

{% if metricbeatEnabled is defined && metricbeatEnabled %}

echo "Metricbeat configured to run, starting monitor"

if [ ! -d /metricbeat ]; then
  mkdir /metricbeat

  chown {{metricbeatRunAsUser}}: /metricbeat
fi

{% if metricbeatBinPath is defined %}
{{metricbeatBinPath}}/setuser {{metricbeatRunAsUser}} /app/metricbeat.sh &
{% else %}
setuser {{metricbeatRunAsUser}} /app/metricbeat.sh &
{% endif %}

{% else %}

echo "Metricbeat not configured to run, skipping"

{% endif %}
