#!/bin/bash
set -e

function prepend-with-date {
  while read line
  do
    echo $(date +%Y-%m-%dT%H:%M:%S%z) $line
  done
}

{% set cluster_data = jsonMap(container.clusterData()) %}
{% set instance_data = jsonMap(container.instanceData()) %}

# Since 7.7.0 we've switched to use upstream images which have different file location
if [ -d /usr/share/kibana ]; then
    KIBANA_HOME=/usr/share/kibana
else
    KIBANA_HOME=/kibana
fi

if [[ $(id -u) -eq 0 ]]; then
    echo "ERROR: kibana.sh running as uid 0 (root), exiting."
    exit 1
fi

cd /app

mkdir -p logs
BOOT_LOG_FILE=logs/boot.log
# save stdout and stderr for later
exec 3>&1 4>&2
exec >  >(prepend-with-date | tee -a $BOOT_LOG_FILE)
exec 2> >(prepend-with-date | tee -a $BOOT_LOG_FILE >&2)

echo "Booting at $(date)"

echo "Done preparing, starting Kibana. See Kibana logs for further output."

# used by the request-filter in kibana
export CLUSTER_NAME={{ container.id().group() }}
# used by the cloud headers patch in kibana
export ELASTICSEARCH_CLUSTER_NAME={{ cluster_data.elasticsearch_cluster_id }}

# used by metricbeat
export ECE_COMPONENT="kibana"
export ECE_CLUSTER_NAME="{{ container.id().group() }}"
export ECE_INSTANCE_ID="{{ container.id().name() }}"
export ECE_CLUSTER_VERSION="{{ container.versionString() }}"

# restore stdout and stderr
exec 1>&3 2>&4

# TODO: add a marker for found-es-monitor to find? e.g -Dfound.kibana_cluster_name={{ container.id().group() }} -Dfound.kibana_instance_name={{ container.id().name() }}

{# 800MB of max_old_space_size per GB of Kibana container size, subject to a min of 800MB #}
{% set max_old_space_size = (instance_data.instance_capacity|default(1024) / 1024 * 800) | int %}
{% if max_old_space_size < 800 %}
  {% set max_old_space_size = 800 %}
{% endif %}

{% if instance_data.instance_capacity > 128 %}
NODE_OPTIONS="--max-old-space-size={{ max_old_space_size }}" ${KIBANA_HOME}/bin/kibana -c /app/config/kibana.yml $*
{% else %}
${KIBANA_HOME}/bin/kibana -c /app/config/kibana.yml $*
{% endif %}
KB_EXIT_CODE=$?
exit $KB_EXIT_CODE
