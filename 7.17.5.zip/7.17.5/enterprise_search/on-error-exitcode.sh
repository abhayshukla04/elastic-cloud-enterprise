#!/bin/bash -ex
# write stdout/stderr to the oom.log file
exec &>>/app/logs/error-exitcode.log

CODE=$1
WHEN=$(date)
echo "Error exitcode ${CODE} at ${WHEN}"

if [ $# -eq 0 ]; then
    # If no arguments provided, it was invoked by the JVM due to the
    ##  -XX:OnOutOfMemoryError flag. This will actually trigger this
    ##  script to be invoked a second time due to the JVM _actually_
    ##  dying and enterprise_search.sh completing it's execution.
    ##  The second invocation will have the exit code 137.
    if [[ $(type -P killall) ]]; then
        killall -9 java
    else
        pkill -9 java
    fi
    exit 0
fi

HEAP_DUMPS=$(find /app/heap_dumps/ -maxdepth 1 -type f -regex '.*\.hprof')
if [ -n "$HEAP_DUMPS" ]; then
    echo -n "Compressing heap dumps "
    if [[ $(type -P pigz) ]]; then
        # pigz creates regular gz archives, but supports utilizing multiple cores
        echo "with pigz"
        echo "$HEAP_DUMPS" | xargs pigz -p `expr $(nproc) / 2`
        mv /app/heap_dumps/*.hprof.gz /app/heap_dumps/compressed/
    else
        echo "with gzip"
        echo "$HEAP_DUMPS" | xargs gzip
        mv /app/heap_dumps/*.hprof.gz /app/heap_dumps/compressed/
    fi
fi


echo "exiting on-error-exitcode.sh at $(date)"
exit 0
