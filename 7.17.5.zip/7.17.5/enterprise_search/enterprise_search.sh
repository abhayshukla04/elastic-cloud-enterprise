#!/bin/bash

if [[ $(id -u) -eq 0 ]]; then
    echo "ERROR: enterprise_search.sh running as uid 0 (root), exiting."
    exit 1
fi

export JAVA_OPTS="-Xms{{ container.heapSize() }}M -Xmx{{ container.heapSize() }}M -XX:OnOutOfMemoryError=/app/on-error-exitcode.sh"
export FILEBEAT_JAVA_OPTS="-Xmx256M -Xms8M"
export ENT_SEARCH_CONFIG_PATH=/app/config/enterprise_search.yml

{% if heapDumpOnOOM|default(false) %}
if [ -d /app/heap_dumps ]; then
  echo "Enabling heap dump on oom"
  export JAVA_OPTS="$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=/app/heap_dumps"
fi
{% endif %}

# Do not abort script if Enterprise Search returns error code
set +e

_term() {
   echo "Caught SIGTERM"
   kill -TERM $(cat /app/es.pid)
}

trap _term TERM

/usr/share/enterprise-search/bin/enterprise-search all &

ENT_SEARCH_PID=$!
wait ${ENT_SEARCH_PID}
ENT_SEARCH_EXIT_CODE=$?
trap - TERM
wait ${ENT_SEARCH_PID}
# The double wait above is deliberate as the first one returns immediately after TERM signal gets trapped.
# Ref: https://github.com/elastic/cloud-assets/pull/451
if [ "$ENT_SEARCH_EXIT_CODE" -ge "1" ]; then
    echo "Enterprise Search exited with status $ENT_SEARCH_EXIT_CODE, running /app/on-error-exitcode.sh $ENT_SEARCH_EXIT_CODE"
    /app/on-error-exitcode.sh $ENT_SEARCH_EXIT_CODE
fi
exit $ENT_SEARCH_EXIT_CODE
